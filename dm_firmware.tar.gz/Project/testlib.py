from ctypes import *

fp=CDLL('libfp.so')

